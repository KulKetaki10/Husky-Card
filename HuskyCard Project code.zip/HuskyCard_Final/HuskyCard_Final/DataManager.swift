//
//  DataManager.swift
//  HuskyCard_Final
//
//  Created by Ketaki Kulkarni on 10/02/24.
//

import SwiftUI
import Firebase

class DataManager : ObservableObject {
    @Published var students: [Student] = []
    
    init(){
        fetchStudents()
    }
    func fetchStudents() {
        students.removeAll()
        let db = Firestore.firestore()
        let ref = db.collection("Students")
        ref.getDocuments { snapshot, error in
            guard error == nil else {
                print(error!.localizedDescription)
                return
            }
            
            if let snapshot = snapshot {
                for document in snapshot.documents {
                    let data = document.data()
                    
                    let id = data["id"] as? String ?? ""
                    let NUID = data["NUID"] as? String ?? ""
                    let email = data["email"] as? String ?? ""
                    let password = data["password"] as? String ?? ""
                    let Name = data["Name"] as? String ?? ""
                    
                    let student = Student(id: id, NUID: NUID, email: email, password: password, Name: Name)
                    self.students.append(student)
                }
            }
            
        }
        
        
    }
}
