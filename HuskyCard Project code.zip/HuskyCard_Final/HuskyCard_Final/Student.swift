//
//  Student.swift
//  HuskyCard_Final
//
//  Created by Ketaki Kulkarni on 10/02/24.
//

import SwiftUI

struct Student: Identifiable {
    var id: String
    var NUID: String
    var email: String
    var password: String
    var Name: String
}
