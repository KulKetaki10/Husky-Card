//
//  HuskyCardViewController.swift
//  HuskyCard_Final
//
//  Created by Ketaki Kulkarni on 10/02/24.
//

import UIKit

class HuskyCardViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
}
